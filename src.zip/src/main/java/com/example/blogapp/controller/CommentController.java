package com.example.blogapp.controller;

import com.example.blogapp.model.Comment;
import com.example.blogapp.repository.CommentRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/comments")
@CrossOrigin(origins = "*")
public class CommentController {

    private final CommentRepository commentRepository;

    public CommentController(CommentRepository commentRepository) {
        this.commentRepository = commentRepository;
    }

    @GetMapping("/post/{postId}")
    public List<Comment> getCommentsByPost(@PathVariable Long postId) {
        return commentRepository.findByPostIdOrderByCreatedAtAsc(postId);
    }

    @PostMapping
    public ResponseEntity<?> addComment(@RequestBody Comment comment) {
        if (comment.getPostId() == null || comment.getAuthorName() == null
                || comment.getContent() == null || comment.getContent().isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Missing comment details"));
        }
        comment.setCreatedAt(LocalDateTime.now());
        return ResponseEntity.status(HttpStatus.CREATED).body(commentRepository.save(comment));
    }
}