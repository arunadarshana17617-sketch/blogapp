package com.example.blogapp.controller;

import com.example.blogapp.model.Post;
import com.example.blogapp.repository.PostRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/posts")
@CrossOrigin(origins = "*")
public class PostController {

    private final PostRepository postRepository;

    public PostController(PostRepository postRepository) {
        this.postRepository = postRepository;
    }

    @GetMapping
    public List<Post> getPosts(@RequestParam(required = false) String category) {
        if (category != null && !category.isBlank() && !category.equalsIgnoreCase("ALL")) {
            return postRepository.findByCategoryIgnoreCaseOrderByCreatedAtDesc(category);
        }
        return postRepository.findAllByOrderByCreatedAtDesc();
    }

    @PostMapping
    public ResponseEntity<?> createPost(
            @RequestParam String title,
            @RequestParam String content,
            @RequestParam String category,
            @RequestParam Long authorId,
            @RequestParam String authorName,
            @RequestParam(required = false) MultipartFile photo
    ) {
        if (title.isBlank() || content.isBlank() || category.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Title, category, and content are required"));
        }

        String imageUrl = null;
        if (photo != null && !photo.isEmpty()) {
            try {
                Path uploadPath = Paths.get("uploads");
                Files.createDirectories(uploadPath);
                String original = Path.of(photo.getOriginalFilename()).getFileName().toString();
                String filename = UUID.randomUUID() + "_" + original;
                Path target = uploadPath.resolve(filename);
                Files.copy(photo.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);
                imageUrl = "/uploads/" + filename;
            } catch (IOException e) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(Map.of("message", "Failed to upload photo"));
            }
        }

        Post post = new Post();
        post.setTitle(title);
        post.setContent(content);
        post.setCategory(category);
        post.setImageUrl(imageUrl);
        post.setAuthorId(authorId);
        post.setAuthorName(authorName);
        post.setCreatedAt(LocalDateTime.now());

        return ResponseEntity.status(HttpStatus.CREATED).body(postRepository.save(post));
    }
}